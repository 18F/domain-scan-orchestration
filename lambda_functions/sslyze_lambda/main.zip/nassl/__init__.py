# -*- coding: utf-8 -*-


__author__ = 'Alban Diquet'
__version__ = '0.16.3'

