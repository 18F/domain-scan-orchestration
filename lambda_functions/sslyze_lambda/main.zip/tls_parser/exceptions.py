
class NotEnoughData(ValueError):
    pass


class UnknownTypeByte(ValueError):
    pass


class UnknownTlsVersionByte(ValueError):
    pass
