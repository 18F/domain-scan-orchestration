var pa11y = require('pa11y');

var test = pa11y();

exports.myHandler = function(event, context, callback) {
	test.run(event.url, function (error, results) {
    	/* ... */
	});
   callback(null, "pa11y ran");
}
